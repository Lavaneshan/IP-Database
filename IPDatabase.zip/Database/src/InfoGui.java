import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.border.Border;

public class InfoGui extends JFrame implements ActionListener {
	
	private JTextArea TextLabel = new JTextArea();
	private JTextArea TextLabelTitel = new JTextArea();
	private Border border = BorderFactory.createLineBorder(Color.BLACK, 2);
	private Border border2 = BorderFactory.createLineBorder(Color.BLACK, 4);
	private JButton ButtonOkey = new JButton("GO!");
	private LoginGui lg = new LoginGui();
	private JPanel InfoPanel = new JPanel();
	private Color K�rbisgelb = new Color(54, 57, 63);  
	private Color MangoGelb = new Color(255, 255, 255);
	private Color hellgrau = new Color(242, 242, 242);
;
	
	public InfoGui() {
	
	
	InfoPanel.setLayout(null);
		
	TextLabelTitel.setBounds(15,15,250,50);
	TextLabelTitel.setBorder(border);
	TextLabelTitel.setText("           What's that?");
	TextLabelTitel.setEditable(false);
	TextLabelTitel.setFont(TextLabel.getFont().deriveFont(Font.BOLD, 20));
	TextLabelTitel.setBackground(MangoGelb);
	
	TextLabel.setBounds(80,75,130,90);
	TextLabel.setBorder(border);
	TextLabel.setText("  \n   This program is \n   used to enter  \n   and manage IPs.");
	TextLabel.setEditable(false);
	TextLabel.setFont(TextLabel.getFont().deriveFont(Font.BOLD, 13));
	TextLabel.setBackground(MangoGelb);

	
	ButtonOkey.setBounds(90, 175, 110, 40);
	ButtonOkey.setBackground(hellgrau);
	ButtonOkey.setOpaque(true);
	ButtonOkey.setForeground(Color.BLACK);
	
	ButtonOkey.addActionListener(this);
	
	InfoPanel.add(ButtonOkey);
	InfoPanel.add(TextLabel);
	InfoPanel.add(TextLabelTitel);

	add(InfoPanel);
	setLocationRelativeTo(null);
	setTitle("InfoGui");
	setDefaultCloseOperation(EXIT_ON_CLOSE);
	setSize(300, 300);
	setResizable(false);
	InfoPanel.setBackground(MangoGelb);
	InfoPanel.setBorder(border2);
	setVisible(true);
}
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == ButtonOkey) {
			lg.LoginGui();
			this.dispose();
	}

	}
}
