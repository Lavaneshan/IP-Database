import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.Border;

public class LoginGui extends JFrame implements ActionListener {

	private JButton ButtonLogin = new JButton("Login");
	private JButton ButtonCancel = new JButton("Cancel");
	private JLabel LabelUsername = new JLabel("Username: ");
	private JLabel LabelPassword = new JLabel("Password: ");
	private JTextField TextUsername = new JTextField();
	private JPasswordField TextPassword = new JPasswordField(12);
	private JPanel LoginPanel = new JPanel();
	private Border border = BorderFactory.createLineBorder(Color.BLACK, 2);
	private Border border2 = BorderFactory.createLineBorder(Color.BLACK, 4);
	private Color K�rbisgelb = new Color(255, 130, 1);
	private Color Weiss = new Color(255, 255, 255);
	private Color hellgrau = new Color(242, 242, 242);
	StartGui stg = new StartGui();

	public void LoginGui() {

		LoginPanel.setLayout(null);

		LabelUsername.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
		LabelUsername.setBorder(border);
		LabelUsername.setBounds(20, 30, 110, 40);
		LabelUsername.setBackground(hellgrau);
		LabelUsername.setOpaque(true);
		LabelUsername.setHorizontalAlignment(JLabel.CENTER);

		TextUsername.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
		TextUsername.setBorder(border);
		TextUsername.setBounds(160, 30, 110, 40);
		TextUsername.setBackground(Color.WHITE);
		TextUsername.setOpaque(true);
		TextUsername.setHorizontalAlignment(JTextField.CENTER);

		LabelPassword.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
		LabelPassword.setBorder(border);
		LabelPassword.setBounds(20, 100, 110, 40);
		LabelPassword.setBackground(hellgrau);
		LabelPassword.setOpaque(true);
		LabelPassword.setHorizontalAlignment(JLabel.CENTER);

		TextPassword.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
		TextPassword.setBorder(border);
		TextPassword.setBounds(160, 100, 110, 40);
		TextPassword.setBackground(Color.WHITE);
		TextPassword.setOpaque(true);
		TextPassword.setHorizontalAlignment(JTextField.CENTER);

		ButtonLogin.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
		ButtonLogin.setBorder(border);
		ButtonLogin.setBounds(30, 175, 110, 40);
		ButtonLogin.setBackground(Color.LIGHT_GRAY);
		ButtonLogin.setOpaque(true);
		ButtonLogin.setForeground(Color.BLACK);

		ButtonCancel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
		ButtonCancel.setBorder(border);
		ButtonCancel.setBounds(150, 175, 110, 40);
		ButtonCancel.setBackground(Color.LIGHT_GRAY);
		ButtonCancel.setOpaque(true);
		ButtonCancel.setForeground(Color.BLACK);

		LoginPanel.setBorder(border2);
		LoginPanel.setBackground(Weiss);
		LoginPanel.add(LabelUsername);
		LoginPanel.add(LabelPassword);
		LoginPanel.add(TextUsername);
		LoginPanel.add(TextPassword);
		LoginPanel.add(ButtonLogin);
		LoginPanel.add(ButtonCancel);

		ButtonLogin.addActionListener(this);
		ButtonCancel.addActionListener(this);

		add(LoginPanel);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setTitle("Login");
		setSize(300, 300);
		setResizable(false);
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == ButtonLogin) {
			String userText;
			String pwdText;
			userText = TextUsername.getText();
			pwdText = TextPassword.getText();
			if (userText.equalsIgnoreCase("Admin") && pwdText.equalsIgnoreCase("Frenkendorf19")) {
				this.dispose();
				stg.setVisible(true);
			} else {
				JOptionPane.showMessageDialog(this, "Invalid Username or Password");
				{

				}
			}
		}
		{
			if (e.getSource() == ButtonCancel) {
				this.dispose();
			}
		}
	}
}