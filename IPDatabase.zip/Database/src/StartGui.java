import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;

public class StartGui extends JFrame implements ActionListener {

	private JButton ButtonEntry = new JButton("Write an Entry");
	private JButton ButtonDatabase = new JButton("IP Database");
	private JPanel StartPanel = new JPanel();
	private Border border = BorderFactory.createLineBorder(Color.BLACK, 2);
	private Border border2 = BorderFactory.createLineBorder(Color.BLACK, 4);
	private DatabaseGui dbg = new DatabaseGui();
	private Color Weiss = new Color(255, 255, 255);
	private Color hellgrau = new Color(242, 242, 242);

	
	public StartGui() {

		StartPanel.setLayout(null);

		ButtonEntry.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
		ButtonEntry.setBorder(border);
		ButtonEntry.setBounds(160, 20, 110, 210);
		ButtonEntry.setBackground(Color.LIGHT_GRAY);
		ButtonEntry.setOpaque(true);
		ButtonEntry.setForeground(Color.BLACK);

		ButtonDatabase.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
		ButtonDatabase.setBorder(border);
		ButtonDatabase.setBounds(20, 20, 110, 210);
		ButtonDatabase.setBackground(Color.LIGHT_GRAY);
		ButtonDatabase.setOpaque(true);
		ButtonDatabase.setForeground(Color.BLACK);

		StartPanel.add(ButtonEntry);
		StartPanel.add(ButtonDatabase);

		ButtonEntry.addActionListener(this);
		ButtonDatabase.addActionListener(this);

		add(StartPanel);
		StartPanel.setBorder(border2);
		StartPanel.setBackground(Weiss);
		setLocationRelativeTo(null);
		setTitle("Start");
		setSize(300, 300);
		setResizable(false);
		setVisible(false);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == ButtonEntry) {
			dbg.EntryGui();
			dbg.DeleteEditGui();
	
		 }
		else if (e.getSource() == ButtonDatabase) {
			dbg.setVisible(true);
			
}	
	}
}
