
public class MainGui {

	public static void main(String[] args) {
		
		InfoGui ig = new InfoGui();

		
	}

}
