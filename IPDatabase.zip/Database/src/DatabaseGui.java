
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.Border;
import javax.swing.JLabel;
import javax.swing.JTextField;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;

import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.sql.DatabaseMetaData;
import java.text.NumberFormat;
import java.awt.Color;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class DatabaseGui extends JFrame implements ActionListener {
	private JButton ButtonOk = new JButton("OK");
	private JButton ButtonCancel = new JButton("Delete");
	private JButton ButtonBack = new JButton("Back");
	private JButton ButtonBackEdit = new JButton("Back");
	private JButton ButtonEdit = new JButton("Edit");
	private JLabel LabelName = new JLabel("Name : ");
	private JLabel LabelIp = new JLabel("IP : ");
	private JLabel LabelDescription = new JLabel("Description : ");
	private JTextField TextName = new JTextField();
	private JTextField TextIp = new JTextField();
	private JTextField TextDescription = new JTextField();
	private JPanel EntryPanel = new JPanel();
	private Border border = BorderFactory.createLineBorder(Color.BLACK, 2);
	private DefaultTableModel model = new DefaultTableModel();
	private JFrame frame = new JFrame();
	private JFrame frame2 = new JFrame();
	private JTable table = new JTable();
	private JTextField TextNameEdit = new JTextField();
	private JTextField TextIpEdit = new JTextField();
	private JTextField TextDescriptionEdit = new JTextField();
	private JPanel EditPanel = new JPanel();
	private JButton ButtonOkEdit = new JButton("OK");
	private JButton ButtonDeleteEdit = new JButton("Delete");
	private Object[] row = new Object[3];
	private Color Weiss = new Color(255, 255, 255);
	private Color hellgrau = new Color(242, 242, 242);
	private Border border2 = BorderFactory.createLineBorder(Color.BLACK, 4);

	public DatabaseGui() {
		this.DatabaseGui2();
	}

	public void EntryGui() {

		EntryPanel.setLayout(null);

		LabelName.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
		LabelName.setBorder(border);
		LabelName.setBounds(20, 20, 100, 30);
		LabelName.setBackground(hellgrau);
		LabelName.setOpaque(true);
		LabelName.setHorizontalAlignment(JLabel.CENTER);

		TextName.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
		TextName.setBorder(border);
		TextName.setBounds(160, 20, 100, 30);
		TextName.setBackground(Color.WHITE);
		TextName.setOpaque(true);
		TextName.setHorizontalAlignment(JTextField.CENTER);

		LabelIp.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
		LabelIp.setBorder(border);
		LabelIp.setBounds(20, 70, 100, 30);
		LabelIp.setBackground(hellgrau);
		LabelIp.setOpaque(true);
		LabelIp.setHorizontalAlignment(JLabel.CENTER);

		TextIp.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
		TextIp.setBorder(border);
		TextIp.setBounds(160, 70, 100, 30);
		TextIp.setBackground(Color.WHITE);
		TextIp.setOpaque(true);
		TextIp.setHorizontalAlignment(JTextField.CENTER);
		TextIp.addKeyListener(keyListener);

		LabelDescription.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
		LabelDescription.setBorder(border);
		LabelDescription.setBounds(20, 120, 100, 30);
		LabelDescription.setBackground(hellgrau);
		LabelDescription.setOpaque(true);
		LabelDescription.setHorizontalAlignment(JLabel.CENTER);

		TextDescription.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
		TextDescription.setBorder(border);
		TextDescription.setBounds(160, 120, 100, 30);
		TextDescription.setBackground(Color.WHITE);
		TextDescription.setOpaque(true);
		TextDescription.setHorizontalAlignment(JTextField.CENTER);

		ButtonOk.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
		ButtonOk.setBorder(border);
		ButtonOk.setBounds(30, 180, 100, 30);
		ButtonOk.setBackground(Color.LIGHT_GRAY);
		ButtonOk.setOpaque(true);
		ButtonOk.setForeground(Color.BLACK);

		ButtonCancel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
		ButtonCancel.setBorder(border);
		ButtonCancel.setBounds(150, 180, 100, 30);
		ButtonCancel.setBackground(Color.LIGHT_GRAY);
		ButtonCancel.setOpaque(true);
		ButtonCancel.setForeground(Color.BLACK);

		ButtonBack.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
		ButtonBack.setBorder(border);
		ButtonBack.setBounds(90, 220, 100, 30);
		ButtonBack.setBackground(Color.GRAY);
		ButtonBack.setOpaque(true);
		ButtonBack.setForeground(Color.BLACK);

		frame.add(EntryPanel);

		EntryPanel.add(LabelName);
		EntryPanel.add(TextName);
		EntryPanel.add(LabelIp);
		EntryPanel.add(TextIp);
		EntryPanel.add(LabelDescription);
		EntryPanel.add(TextDescription);
		EntryPanel.add(ButtonOk);
		EntryPanel.add(ButtonCancel);
		EntryPanel.add(ButtonBack);

		ButtonOk.addActionListener(this);
		EntryPanel.setBorder(border2);
		frame.setLocationRelativeTo(null);
		frame.setTitle("Write an Entry");
		frame.setSize(300, 300);
		frame.setResizable(false);
		frame.setVisible(true);

	}

	public void EditDatabaseGui() {

		EditPanel.setLayout(null);

		TextNameEdit.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
		TextNameEdit.setBorder(border);
		TextNameEdit.setBounds(20, 20, 250, 40);
		TextNameEdit.setBackground(hellgrau);
		TextNameEdit.setOpaque(true);
		TextNameEdit.setHorizontalAlignment(JTextField.CENTER);

		TextIpEdit.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
		TextIpEdit.setBorder(border);
		TextIpEdit.setBounds(20, 80, 250, 40);
		TextIpEdit.setBackground(hellgrau);
		TextIpEdit.setOpaque(true);
		TextIpEdit.setHorizontalAlignment(JTextField.CENTER);
		TextIpEdit.addKeyListener(keyListener);

		TextDescriptionEdit.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
		TextDescriptionEdit.setBorder(border);
		TextDescriptionEdit.setBounds(20, 140, 250, 40);
		TextDescriptionEdit.setBackground(hellgrau);
		TextDescriptionEdit.setOpaque(true);
		TextDescriptionEdit.setHorizontalAlignment(JTextField.CENTER);

		ButtonOkEdit.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
		ButtonOkEdit.setBorder(border);
		ButtonOkEdit.setBounds(30, 200, 110, 40);
		ButtonOkEdit.setBackground(Color.gray);
		ButtonOkEdit.setOpaque(true);
		ButtonOkEdit.setForeground(Color.BLACK);

		ButtonDeleteEdit.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
		ButtonDeleteEdit.setBorder(border);
		ButtonDeleteEdit.setBounds(150, 200, 110, 40);
		ButtonDeleteEdit.setBackground(Color.gray);
		ButtonDeleteEdit.setOpaque(true);
		ButtonDeleteEdit.setForeground(Color.BLACK);

		EditPanel.add(TextNameEdit);
		EditPanel.add(TextIpEdit);
		EditPanel.add(TextDescriptionEdit);
		EditPanel.add(ButtonOkEdit);
		EditPanel.add(ButtonDeleteEdit);

		EditPanel.setBorder(border2);

		frame2.add(EditPanel);
		frame2.setBackground(Weiss);
		frame2.setLocationRelativeTo(null);
		frame2.setTitle("Edit an entry");
		frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame2.setSize(300, 300);
		frame2.setResizable(false);
		frame2.setVisible(true);
	}

	public void DatabaseGui2() {

		Object[] columns = { "Name", "IP", "Description" };

		model.setColumnIdentifiers(columns);

		table.setModel(model);

		table.setBackground(hellgrau);
		table.setRowHeight(20);

		JScrollPane pane = new JScrollPane(table);
		pane.setBounds(0, 0, 300, 200);

		JButton ButtonEdit = new JButton("Edit");
		ButtonEdit.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
		ButtonEdit.setBorder(border);
		ButtonEdit.setBounds(30, 220, 100, 30);
		ButtonEdit.setBackground(hellgrau);
		ButtonEdit.setOpaque(true);
		ButtonEdit.setForeground(Color.BLACK);

		ButtonBackEdit.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
		ButtonBackEdit.setBorder(border);
		ButtonBackEdit.setBounds(150, 220, 100, 30);
		ButtonBackEdit.setBackground(Color.GRAY);
		ButtonBackEdit.setOpaque(true);
		ButtonBackEdit.setForeground(Color.BLACK);

		this.setLayout(null);
		this.add(ButtonEdit);
		this.add(pane);
		this.add(ButtonBackEdit);
		this.setSize(300, 300);
		this.setLocationRelativeTo(null);
		this.setTitle("Database");
		this.setResizable(false);
		this.setVisible(false);

		ButtonOk.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				row[0] = TextName.getText();
				row[1] = TextIp.getText();
				row[2] = TextDescription.getText();
				model.addRow(row);

				frame.setVisible(false);

			}
		}

		);
		ButtonCancel.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				DeleteEditGui();

			}
		}

		);
		ButtonBack.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				frame.setVisible(false);

			}
		}

		);

		ButtonEdit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				TableEditGui(null);

			}
		}

		);

		ButtonOkEdit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				// Ausgew�hlte Zeile
				int i = table.getSelectedRow();
				// Ver�ndert die Zeile
				if (i >= 0) {
					model.setValueAt(TextNameEdit.getText(), i, 0);
					model.setValueAt(TextIpEdit.getText(), i, 1);
					model.setValueAt(TextDescriptionEdit.getText(), i, 2);
					frame2.setVisible(false);

				} else {
					System.out.println("Update Error");

				}
			}
		}

		);

		ButtonBackEdit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				setVisible(false);
			}

		}

		);

		ButtonDeleteEdit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// Ausgew�hlte Zeile
				int i = table.getSelectedRow();
				if (i >= 0) {
					// Entfernt die Zeile
					model.removeRow(i);
					frame2.setVisible(false);
				} else {
					System.out.println("Delete Error");
				}
			}

		}

		);
	}

	// Klasse um TextField leer zu machen
	public void DeleteEditGui() {

		TextName.setText("");
		TextIp.setText("");
		TextDescription.setText("");
	}

	public void TableEditGui(java.awt.event.MouseEvent evt) {

		DefaultTableModel model = (DefaultTableModel) table.getModel();
		int selectedRowIndex = table.getSelectedRow();
		// Updatet die neu eingegeben Werte
		TextNameEdit.setText(model.getValueAt(selectedRowIndex, 0).toString());
		TextIpEdit.setText(model.getValueAt(selectedRowIndex, 1).toString());
		TextDescriptionEdit.setText(model.getValueAt(selectedRowIndex, 2).toString());
		EditDatabaseGui();
	}

	// Schaut das nur Zahlen und Punkte eingegebn werden kann
	KeyListener keyListener = new KeyListener() {
		public void keyTyped(KeyEvent evt) {

			if (!validate(evt.getKeyChar())) { // get char or keytyped
				evt.consume();
			}
			// Schaut das es nur Dezimal oder Punkt schreiben kann
			if (evt.getKeyChar() == KeyEvent.VK_DECIMAL || evt.getKeyChar() == KeyEvent.VK_PERIOD) {

				String field = TextIp.getText(); // Gibt den String in einem TextField
				String field2 = TextIpEdit.getText(); // Gibt den String in einem TextField
				int index = field.indexOf("."); // Findet ob es Punkt oder Dezimal hat
				int index2 = field2.indexOf(".");// Findet ob es Punkt oder Dezimal hat
				if ((index == -2)) { // Hat es noch andere?
				}

			}
		}
		// �berpr�ft ob es eine Zahl oder Buchstabe ist und gibt es zur�ck
		private boolean validate(char ch) {

			if (!(Character.isDigit(ch) || ch == KeyEvent.VK_BACK_SPACE || ch == KeyEvent.VK_DELETE
					|| ch == KeyEvent.VK_DECIMAL || ch == KeyEvent.VK_PERIOD)) {

				return false;
			}

			return true; // return true, when the if statement above does not meet its conditions
		}

		@Override
		public void keyPressed(KeyEvent e) {

		}

		@Override
		public void keyReleased(KeyEvent e) {

		}

	};

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

	
}
